#define GLEW_STATIC
#include <iostream>
#include <sstream>
#include <glew.h>// MUST INCLUDE glew before glfw!!!
//Creates function pointers to functions in GPU via it's driver
#include <glm.hpp>
#include <gtc/matrix_transform.hpp>
#include <glfw3.h>
//Handles for user input and windows

#include "ShaderProgram.h"
#include "Texture2D.h"
#include "Camera.h"
#include "Mesh.h"

const char* APP_TITLE = "Hello Triangle!";
int WIDTH = 1024;
int HEIGHT = 768;
const bool FULLSCREEN = false;
const float MOUSE_SENSITIVITY = 0.1f;
GLFWwindow* gWindow = NULL;
bool gWireFrame = false;
const std::string texture1FileName = "wooden_crate.jpg";
const std::string texture2FileName = "grid.jpg";

FPSCamera fpsCamera(glm::vec3(0.0f, 1.0f, 5.0f));
const double ZOOM_SENSITIVITY = -3.0f;
const float MOVE_SPEED = 5.0f;

void glfw_onKey(GLFWwindow* window, int key, int scancode, int action, int mode);
void glfw_OnFrameBufferResize(GLFWwindow* window, int width, int height);
void glfw_OnMouseMove(GLFWwindow* window, double posX, double posY);
void glfw_OnMouseScroll(GLFWwindow* window, double deltaX, double deltaY);
void update(double elapsedTime);
void showFPS(GLFWwindow* window);
bool initOpenGL();


int main()
{
    if (!initOpenGL()) {
        std::cerr << "Error initializing OpenGL" << std::endl;
        return -1;
    }

    glm::vec3 cubePos = glm::vec3(0.0f, 0.0f, -10.0f);
    glm::vec3 floorPos = glm::vec3(0.0f, -1.0f, 0.0f);



    ShaderProgram lightShader; // Just to render light in scene
    lightShader.loadShaders("basic.vert", "basic.frag");

    ShaderProgram lightingShader;  // Shader for lighting enabled objects
    lightingShader.loadShaders("light.vert", "light.frag");

    //load meshes and textures
    const int numModels = 6;
    glm::vec3 modelPos[] = {
        glm::vec3(-3.5f,0.0f,0.0f),     //crate1
        glm::vec3(3.5f,0.0f,0.0f),      //crate2
        glm::vec3(0.0f,0.0f,-2.0f),     //robot
        glm::vec3(0.0f,0.0f,0.0f),      //floor
        glm::vec3(0.0f,0.0f,2.0f),      //pin
        glm::vec3(-2.0f,0.0f,2.0f)      //bunny
    };
    glm::vec3 modelScale[] = {
        glm::vec3(1.0f,1.0f,1.0f),
        glm::vec3(1.0f,1.0f,1.0f),
        glm::vec3(1.0f,1.0f,1.0f),
        glm::vec3(10.0f,1.0f,10.0f),
        glm::vec3(0.1f,0.1f,0.1f),
        glm::vec3(1.0f,1.0f,1.0f)
    };
    Mesh mesh[numModels];
    Texture2D textures[numModels];

    mesh[0].loadOBJ("crate.obj");
    mesh[1].loadOBJ("woodcrate.obj");
    mesh[2].loadOBJ("robot.obj");
    mesh[3].loadOBJ("floor.obj");
    mesh[4].loadOBJ("bowling_pin.obj");
    mesh[5].loadOBJ("bunny.obj");

    textures[0].loadTexture("crate.jpg", true);
    textures[1].loadTexture("wooden_crate.jpg", true);
    textures[2].loadTexture("robot_diffuse.jpg", true);
    textures[3].loadTexture("tile_floor.jpg", true);
    textures[4].loadTexture("AMF.tga", true);
    textures[5].loadTexture("bunny_diffuse.jpg", true);

    Mesh lightMesh;
    lightMesh.loadOBJ("light.obj");

    double lastTime = glfwGetTime();
    float lightAngle = 0.0f;

    while (!glfwWindowShouldClose(gWindow)) {
        showFPS(gWindow);

        double currentTime = glfwGetTime();
        double deltaTime = currentTime - lastTime;
        lastTime = currentTime;

        glfwPollEvents();//Poll for keyboard/mouse inputs etc. Input uses callbacks.
        update(deltaTime);

        glClear(GL_COLOR_BUFFER_BIT);//Clear color buffer with color in clear color
        glClear(GL_DEPTH_BUFFER_BIT);


        glm::mat4 model, view, projection;
        model = glm::mat4(1.0f); view = glm::mat4(1.0f); projection = glm::mat4(1.0f);

        view = fpsCamera.getViewMatrix();

        projection = glm::perspective(glm::radians(45.0f), (float)WIDTH/(float)HEIGHT, 0.1f, 100.0f);
        glm::vec3 lightPos(0.0f, 1.0f, 10.0f);
        glm::vec3 lightColor(1.0f, 1.0f, 1.0f);
        glm::vec3 lightDirection(0.0f, -0.9f, -0.17f);

        //move light
        lightAngle += (float)deltaTime * 50.0f;
        if (lightAngle >= 360.0f) {
            lightAngle -= 360.0f;
        }

        lightPos.x = 8.0f * sinf(glm::radians(lightAngle));

        lightingShader.use();
        lightingShader.setUniform("view", view);
        lightingShader.setUniform("projection", projection);
        lightingShader.setUniform("viewPos", fpsCamera.getPosition());

        lightingShader.setUniform("light.ambient", glm::vec3(0.2f,0.2f,0.2f));
        lightingShader.setUniform("light.diffuse", lightColor);
        lightingShader.setUniform("light.specular", glm::vec3(0.2f,0.2f,0.2f));
        lightingShader.setUniform("light.position", lightPos);

        for (int i = 0; i < numModels; i++) {
            model = glm::translate(glm::mat4(1.0f), modelPos[i]) * glm::scale(glm::mat4(1.0f), modelScale[i]);
            lightingShader.setUniform("model", model);

            lightingShader.setUniform("material.ambient", glm::vec3(0.1f, 0.1f, 0.1f));
            lightingShader.setUniformSampler("material.diffuseMap", 0);
            lightingShader.setUniform("material.specular", glm::vec3(0.1f, 0.1f, 0.1f));
            lightingShader.setUniform("material.shininess", 32.0f);

            textures[i].bind(0);
            mesh[i].draw();
            textures[i].unbind();
        }

        //Render the light...
        model = glm::translate(glm::mat4(1.0f), lightPos);
        lightShader.use();
        lightShader.setUniform("lightColor", lightColor);
        lightShader.setUniform("model", model);
        lightShader.setUniform("view", view);
        lightShader.setUniform("projection", projection);
        lightMesh.draw();

        glfwSwapBuffers(gWindow);
    }


    glfwTerminate();
    return 0;
}

void update(double elapsedTime)
{
    double mouseX, mouseY;
    mouseX = 0; mouseY = 0;

    glfwGetCursorPos(gWindow, &mouseX, &mouseY);

    fpsCamera.rotate((float)(WIDTH / 2.0 - mouseX) * MOUSE_SENSITIVITY, (float)(HEIGHT / 2.0 - mouseY) * MOUSE_SENSITIVITY);

    glfwSetCursorPos(gWindow, WIDTH / 2, HEIGHT / 2);

    if (glfwGetKey(gWindow, GLFW_KEY_W) == GLFW_PRESS) {
        fpsCamera.move(MOVE_SPEED * (float)elapsedTime * fpsCamera.getLook());
    }
    else if (glfwGetKey(gWindow, GLFW_KEY_S) == GLFW_PRESS) {
        fpsCamera.move(-1 * MOVE_SPEED * (float)elapsedTime * fpsCamera.getLook());
    }


    if (glfwGetKey(gWindow, GLFW_KEY_D) == GLFW_PRESS) {
        fpsCamera.move(MOVE_SPEED * (float)elapsedTime * fpsCamera.getRight());
    }
    else if (glfwGetKey(gWindow, GLFW_KEY_A) == GLFW_PRESS) {
        fpsCamera.move(-1 * MOVE_SPEED * (float)elapsedTime * fpsCamera.getRight());
    }


    if (glfwGetKey(gWindow, GLFW_KEY_Q) == GLFW_PRESS) {
        fpsCamera.move(MOVE_SPEED * (float)elapsedTime * fpsCamera.getUp());
    }
    else if (glfwGetKey(gWindow, GLFW_KEY_Z) == GLFW_PRESS) {
        fpsCamera.move(-1 * MOVE_SPEED * (float)elapsedTime * fpsCamera.getUp());
    }
}

bool initOpenGL() {
    if (!glfwInit()) {
        std::cout << "GLFW Init Failed" << std::endl;
        return false;
    }

    //Set minimum OpenGL version to 3.3 Core
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    //----------

    //GLFWwindow* pWindow;
    if (FULLSCREEN) {
        GLFWmonitor* pMonitor = glfwGetPrimaryMonitor();
        const GLFWvidmode* pVmode = glfwGetVideoMode(pMonitor);
        if (pVmode != NULL) {
            gWindow = glfwCreateWindow(pVmode->width, pVmode->height, APP_TITLE, pMonitor, NULL);
            WIDTH = pVmode->width;
            HEIGHT = pVmode->height;
        }
        else {
            gWindow = glfwCreateWindow(WIDTH, HEIGHT, APP_TITLE, NULL, NULL);
        }
    }
    else {
        gWindow = glfwCreateWindow(WIDTH, HEIGHT, APP_TITLE, NULL, NULL);
    }
    //glViewport(0, 0, WIDTH, HEIGHT);
    if (gWindow == NULL) {
        std::cerr << "Init OpenGL Context Fail" << std::endl;
        glfwTerminate();//properly close GLFW
        return false;
    }

    glfwMakeContextCurrent(gWindow);
    //glfwSwapInterval(0);



    glewExperimental = GL_TRUE;
    //Initialize GLEW...
    if (glewInit() != GLEW_OK) {
        std::cerr << "Init Glew Fail" << std::endl;
        glfwTerminate();
        return false;
    }

    glfwSetKeyCallback(gWindow, glfw_onKey);
    glfwSetWindowSizeCallback(gWindow, glfw_OnFrameBufferResize);
    glfwSetCursorPosCallback(gWindow, glfw_OnMouseMove);
    glfwSetScrollCallback(gWindow, glfw_OnMouseScroll);

    //Hide and grab cursor, unlimited movement
    glfwSetInputMode(gWindow, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
    glfwSetCursorPos(gWindow, WIDTH / 2, HEIGHT / 2);

    glClearColor(0.23f, 0.38f, 0.47f, 1.0f);
    glViewport(0, 0, WIDTH, HEIGHT);
    glEnable(GL_DEPTH_TEST);

    return true;
}

void glfw_OnFrameBufferResize(GLFWwindow* window, int width, int height) {
    WIDTH = width;
    HEIGHT = height;
    glViewport(0, 0, width, height);
}

void glfw_OnMouseMove(GLFWwindow* window, double posX, double posY) {
    //static glm::vec2 lastMousePos = glm::vec2(0, 0);

    //// Update angles based on Left Mouse Button input to orbit around the cube
    //if (glfwGetMouseButton(gWindow, GLFW_MOUSE_BUTTON_LEFT) == 1)
    //{
    //    // each pixel represents a quarter of a degree rotation (this is our mouse sensitivity)
    //    gYaw -= ((float)posX - lastMousePos.x) * MOUSE_SENSITIVITY;
    //    gPitch += ((float)posY - lastMousePos.y) * MOUSE_SENSITIVITY;
    //}

    //// Change orbit camera radius with the Right Mouse Button
    //if (glfwGetMouseButton(gWindow, GLFW_MOUSE_BUTTON_RIGHT) == 1)
    //{
    //    float dx = 0.01f * ((float)posX - lastMousePos.x);
    //    float dy = 0.01f * ((float)posY - lastMousePos.y);
    //    gRadius += dx - dy;
    //}

    //lastMousePos.x = (float)posX;
    //lastMousePos.y = (float)posY;
}

void glfw_OnMouseScroll(GLFWwindow* window, double deltaX, double deltaY)
{

}

void glfw_onKey(GLFWwindow* window, int key, int scancode, int action, int mode) {
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS) {
        glfwSetWindowShouldClose(window, GL_TRUE);
    }

    if (key == GLFW_KEY_P && action == GLFW_PRESS) {
        gWireFrame = !gWireFrame;
        if (gWireFrame) {
            glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
        }
        else {
            glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
        }
    }
}

void showFPS(GLFWwindow* window) {
    static double previousSeconds = 0.0;
    static int frameCount = 0;
    double elapsedSeconds;
    double currentSeconds = glfwGetTime(); // Returns seconds since glfwinit


    elapsedSeconds = currentSeconds - previousSeconds;

    // limit text update 5 times a second
    if (elapsedSeconds > 0.35) {
        previousSeconds = currentSeconds;
        double fps = (double)frameCount / elapsedSeconds;
        double msPerFrame = 1000.0 / fps;

        std::ostringstream outs;
        outs.precision(3);
        outs << std::fixed
            << APP_TITLE << "  "
            << "FPS:  " << fps << "  "
            << "Frame Time: " << msPerFrame << " (ms)";
        glfwSetWindowTitle(window, outs.str().c_str());

        frameCount = 0;
    }

    frameCount++;
}