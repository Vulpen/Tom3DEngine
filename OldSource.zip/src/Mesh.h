#pragma once
#ifndef MESH_H
#define MESH_H

#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>
#include <string>
#include <direct.h>

#include "glew.h"
#include "glm.hpp"

struct Vertex
{
	glm::vec3 position;
	glm::vec3 normal;
	glm::vec2 texCoord;
};



class Mesh
{
public:
	Mesh();
	~Mesh();

	bool loadOBJ(const std::string& filename);
	void draw();

private:
	void initBuffers();

	bool mLoaded;
	std::vector<Vertex> mVertices;
	GLuint mvbo;
	GLuint mvao;
};

#endif

