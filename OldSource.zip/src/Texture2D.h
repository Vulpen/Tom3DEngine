#ifndef TEXTURE_2D_H
#define TEXTURE_2D_H
#include <string>
#include <glew.h>

using std::string;

class Texture2D
{
public:
	Texture2D();
	virtual ~Texture2D();

	bool loadTexture(const string& filename, bool generateMipMaps = true);
	void bind(GLuint texUnit = 0);
	void unbind(GLuint texUnit = 0);
private:
	GLuint mTexture; //Identifier for texture

};

#endif // !TEXTURE_2D_H

